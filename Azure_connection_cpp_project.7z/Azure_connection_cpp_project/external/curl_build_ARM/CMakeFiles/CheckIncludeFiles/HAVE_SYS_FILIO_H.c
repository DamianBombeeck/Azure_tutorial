/* */
#include <stdio.h>
#include <inttypes.h>
#include <sys/filio.h>


int main(void){return 0;}

