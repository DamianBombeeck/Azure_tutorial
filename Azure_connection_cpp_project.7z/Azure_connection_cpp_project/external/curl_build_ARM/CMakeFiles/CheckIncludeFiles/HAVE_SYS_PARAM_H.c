/* */
#include <stdio.h>
#include <inttypes.h>
#include <sys/ioctl.h>
#include <sys/param.h>


int main(void){return 0;}

