/* */
#include <stdio.h>
#include <inttypes.h>
#include <sys/ioctl.h>
#include <sys/param.h>
#include <sys/poll.h>
#include <sys/resource.h>


int main(void){return 0;}

