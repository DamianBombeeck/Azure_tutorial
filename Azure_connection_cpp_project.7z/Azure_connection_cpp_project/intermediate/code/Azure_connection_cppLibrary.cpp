﻿#include "Azure_connection_cppLibrary.hpp"
#include "Arp/System/Core/CommonTypeName.hxx"
#include "MyComponent.hpp"

namespace Azure_connection_cpp
{

Azure_connection_cppLibrary::Azure_connection_cppLibrary(AppDomain& appDomain)
    : MetaLibraryBase(appDomain, ARP_VERSION_CURRENT, typeDomain)
    , typeDomain(CommonTypeName<Azure_connection_cppLibrary>().GetNamespace())
{
    this->componentFactory.AddFactoryMethod(CommonTypeName<::Azure_connection_cpp::MyComponent>(), &::Azure_connection_cpp::MyComponent::Create);
    this->InitializeTypeDomain();
}

void Azure_connection_cppLibrary::Main(AppDomain& appDomain)
{
    SingletonBase::CreateInstance(appDomain);
}

extern "C" ARP_CXX_SYMBOL_EXPORT ILibrary& ArpDynamicLibraryMain(AppDomain& appDomain)
{
    Azure_connection_cppLibrary::Main(appDomain);
    return  Azure_connection_cppLibrary::GetInstance();
}

} // end of namespace Azure_connection_cpp
