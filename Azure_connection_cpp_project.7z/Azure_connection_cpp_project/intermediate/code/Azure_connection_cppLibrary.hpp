﻿#pragma once
#include "Arp/System/Core/Arp.h"
#include "Arp/System/Core/AppDomain.hpp"
#include "Arp/System/Core/Singleton.hxx"
#include "Arp/System/Core/Library.h"
#include "Arp/Plc/Commons/Meta/MetaLibraryBase.hpp"
#include "Arp/Plc/Commons/Meta/TypeSystem/TypeDomain.hpp"

namespace Azure_connection_cpp
{

using namespace Arp::System::Acf;
using namespace Arp::Plc::Commons::Meta;
using namespace Arp::Plc::Commons::Meta::TypeSystem;

class Azure_connection_cppLibrary : public MetaLibraryBase, public Singleton<Azure_connection_cppLibrary>
{
public: // typedefs
    typedef Singleton<Azure_connection_cppLibrary> SingletonBase;

public: // construction/destruction
    Azure_connection_cppLibrary(AppDomain& appDomain);
    virtual ~Azure_connection_cppLibrary() = default;

public: // static operations (called through reflection)
    static void Main(AppDomain& appDomain);

private: // methods
    void InitializeTypeDomain();

private: // deleted methods
    Azure_connection_cppLibrary(const Azure_connection_cppLibrary& arg) = delete;
    Azure_connection_cppLibrary& operator= (const Azure_connection_cppLibrary& arg) = delete;

private:  // fields
    TypeDomain typeDomain;
};

extern "C" ARP_CXX_SYMBOL_EXPORT ILibrary& ArpDynamicLibraryMain(AppDomain& appDomain);

///////////////////////////////////////////////////////////////////////////////
// inline methods of class Azure_connection_cppLibrary

} // end of namespace Azure_connection_cpp
