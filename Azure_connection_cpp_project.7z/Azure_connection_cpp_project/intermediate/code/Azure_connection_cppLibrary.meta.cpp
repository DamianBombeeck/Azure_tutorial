﻿#include "Arp/System/Core/Arp.h"
#include "Arp/Plc/Commons/Meta/TypeSystem/TypeSystem.h"
#include "MyProgram.hpp"
#include "Azure_connection_cppLibrary.hpp"

namespace Azure_connection_cpp
{

using namespace Arp::Plc::Commons::Meta;

    void Azure_connection_cppLibrary::InitializeTypeDomain()
    {
        this->typeDomain.AddTypeDefinitions
        (
            // Begin TypeDefinitions
            {
                {   // ProgramDefinition: Azure_connection_cpp::MyProgram
                    DataType::Program, CTN<Azure_connection_cpp::MyProgram>(), sizeof(::Azure_connection_cpp::MyProgram), alignof(::Azure_connection_cpp::MyProgram), StandardAttribute::None,
                    {
                        // FieldDefinitions:
                    }
                },
            }
            // End TypeDefinitions
        );
    }

} // end of namespace Azure_connection_cpp

