﻿#include "MyComponent.hpp"

namespace Azure_connection_cpp
{

void MyComponent::RegisterComponentPorts()
{
    this->dataInfoProvider.AddRoot("start_download_input", this->start_download_input);
    this->dataInfoProvider.AddRoot("start_download_output", this->start_download_output);
    this->dataInfoProvider.AddRoot("start_buffer", this->start_buffer);
    this->dataInfoProvider.AddRoot("sizeof_result_string", this->sizeof_result_string);
    this->dataInfoProvider.AddRoot("result_string_byte", this->result_string_byte);
    this->dataInfoProvider.AddRoot("search_var_byte", this->search_var_byte);
}

} // end of namespace Azure_connection_cpp