﻿#include "MyComponentProgramProvider.hpp"
#include "MyProgram.hpp"

namespace Azure_connection_cpp
{

IProgram::Ptr MyComponentProgramProvider::CreateProgramInternal(const String& programName, const String& programType)
{
    if (programType == "MyProgram")
    { 
        return std::make_shared<::Azure_connection_cpp::MyProgram>(this->myComponent, programName);
    }

    // else unknown program
    return nullptr;
}

} // end of namespace Azure_connection_cpp
