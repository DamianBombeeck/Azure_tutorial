﻿#pragma once
#include "Arp/System/Core/Arp.h"
#include "Arp/Plc/Commons/Esm/ProgramProviderBase.hpp"

namespace Azure_connection_cpp
{

using namespace Arp;
using namespace Arp::Plc::Commons::Esm;

//forwards
class MyComponent;

class MyComponentProgramProvider : public ProgramProviderBase
{

public:   // construction/destruction
    MyComponentProgramProvider(MyComponent& myComponentArg);
    virtual ~MyComponentProgramProvider() = default;

public:   // IProgramProvider operations
    IProgram::Ptr CreateProgramInternal(const String& programName, const String& programType) override;

private:   // deleted methods
    MyComponentProgramProvider(const MyComponentProgramProvider& arg) = delete;
    MyComponentProgramProvider& operator=(const MyComponentProgramProvider& arg) = delete;

private: // fields
    MyComponent& myComponent;
};

///////////////////////////////////////////////////////////////////////////////
// inline methods of class MyComponentProgramProvider

inline MyComponentProgramProvider::MyComponentProgramProvider(MyComponent& myComponentArg)
    : myComponent(myComponentArg)
{
}

} // end of namespace Azure_connection_cpp
