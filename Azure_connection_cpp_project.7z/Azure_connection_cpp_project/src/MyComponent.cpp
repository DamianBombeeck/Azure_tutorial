﻿#include "MyComponent.hpp"
#include "Arp/Plc/Commons/Esm/ProgramComponentBase.hpp"
#include <string> 
#include <string.h>

namespace Azure_connection_cpp
{
    void MyComponent::Initialize()
    {
        // never remove next line
        ProgramComponentBase::Initialize();
        // subscribe events from the event system (Nm) here
    }

    void MyComponent::LoadConfig()
    {
        // load project config here
    }

    void MyComponent::SetupConfig()
    {
        // never remove next line
        ProgramComponentBase::SetupConfig();
        // setup project config here
    }

    void MyComponent::ResetConfig()
    {
        // never remove next line
        ProgramComponentBase::ResetConfig();
        // implement this inverse to SetupConfig() and LoadConfig()
    }

	void MyComponent::Start(void) 
	{
		workerThreadInstance.Start();
		Log::Info("-------------------------------Thread started");
	}

	void MyComponent::Stop(void) 
	{
		workerThreadInstance.Stop();
		Log::Info("-------------------------------Thread stopped");
	}

	/// Thread Body
	void MyComponent::workerThreadBody(void) 
	{   
        const char* input_search_variable = reinterpret_cast<char*>(search_var_byte);
        const char* Search_syntax = "search_variable: ";
        char variable_buffer[256];

        strncpy(variable_buffer, Search_syntax, sizeof(variable_buffer));
        strncat(variable_buffer, input_search_variable, sizeof(variable_buffer));

        if (start_download_input == true)
        {
            Log::Info("-------------------------------Thread HTTPS REQUEST: REQUEST STARTED");
            struct curl_slist* headers = NULL;
            CURL* curl;
            CURLcode res;

            const char* url = "https://prod-54.westeurope.logic.azure.com:443/workflows/a3138f986cb3499dabc5d1ecc42a8c38/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=01stU3opM0XlI2kU55l6jxVqhQy1rxIgi1HErSEIFo4";
            const char* Content_Type = "Content-Type: application/json";
            const char* Content_Length_H = "Content-Length: 0";
            const char* Search_pointer = "search_pointer: @name";
            const std::string HTTP_buffer;
            headers = NULL;

            curl = curl_easy_init();
            if (curl)
            {
                curl_easy_setopt(curl, CURLOPT_URL, url);
                curl_easy_setopt(curl, CURLOPT_POST, 1L);
            
                headers = curl_slist_append(headers, Content_Type);
                headers = curl_slist_append(headers, Content_Length_H);
                headers = curl_slist_append(headers, Search_pointer);
                headers = curl_slist_append(headers, variable_buffer);

                curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
                curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_data);
                curl_easy_setopt(curl, CURLOPT_WRITEDATA, &HTTP_buffer);

                res = curl_easy_perform(curl);
                curl_easy_cleanup(curl);
                curl_slist_free_all(headers);
                Log::Info("-------------------------------Thread HTTPS REQEUST: RESPONSE RECEIVED");
            } 

            sizeof_result_string = HTTP_buffer.size(); 
            for (int i = 0; i <= sizeof_result_string; i++)
            {
                result_string_byte[i] = HTTP_buffer[i]; 
            }
            
            start_buffer = true;
            start_download_output = true;  		
        }

        if(start_download_input == false)
        {
            start_buffer = false;
            start_download_output = false;            
        }
	}

    size_t MyComponent::write_data(void* ptr, size_t size, size_t nmemb, void* userp)
    {
        ((std::string*)userp)->append((char*)ptr, size * nmemb);
        return size * nmemb;
    }
} // end of namespace Azure_connection_cpp
