﻿#pragma once
#include "Arp/System/Core/Arp.h"
#include "Arp/System/Acf/ComponentBase.hpp"
#include "Arp/System/Acf/IApplication.hpp"
#include "Arp/Plc/Commons/Esm/ProgramComponentBase.hpp"
#include "MyComponentProgramProvider.hpp"
#include "Azure_connection_cppLibrary.hpp"
#include "Arp/Plc/Commons/Meta/MetaLibraryBase.hpp"
#include "Arp/System/Commons/Logging.h"

//ADDED
#include "Arp/System/Acf/IControllerComponent.hpp"
#include "Arp/System/Commons/Threading/WorkerThread.hpp"
#include "Arp/System/Commons/Threading/Thread.hpp"
#include "Arp/System/Commons/Threading/ThreadSettings.hpp"
#include "curl.h" 
#include <string> 

namespace Azure_connection_cpp
{
    using namespace Arp;
    using namespace Arp::System::Acf;
    using namespace Arp::Plc::Commons::Esm;
    using namespace Arp::Plc::Commons::Meta;

    //#component
    class MyComponent : public ComponentBase
                    , public ProgramComponentBase
                    , public IControllerComponent
                    , private Loggable<MyComponent>
    {
    public: // typedefs

    public: // construction/destruction
        MyComponent(IApplication& application, const String& name);
        virtual ~MyComponent() = default;

    public: // IComponent operations
        void Initialize() override;
        void LoadConfig() override;
        void SetupConfig() override;
        void ResetConfig() override;
   
    public: // IControllerComponent operations
        void Start(void);
        void Stop(void);

    public: // ProgramComponentBase operations
        void RegisterComponentPorts() override;

    private: // methods
        MyComponent(const MyComponent& arg) = delete;
        MyComponent& operator= (const MyComponent& arg) = delete;

    public: // static factory operations
        static IComponent::Ptr Create(Arp::System::Acf::IApplication& application, const String& name);
        static size_t write_data(void* ptr, size_t size, size_t nmemb, void* userp);
        
    // Added: IProgramComponent operations
    public:
        IProgramProvider & GetProgramProvider(bool useBackgroundDomain) override;

    // Added: IMetaComponent operations
    public:
        IDataInfoProvider & GetDataInfoProvider(bool isChanging) override;
        IDataNavigator*     GetDataNavigator() override;

    private: // fields
        MyComponentProgramProvider programProvider;
        DataInfoProvider    	   dataInfoProvider;

        // Worker Thread Example
        WorkerThread workerThreadInstance;
        bool startflag = false; 

        void workerThreadBody(void);

    public: // Ports

            //#port
            //#attributes(Input)
            //#name(start_download_input)
            bool start_download_input = false;

            //#port
            //#attributes(Output)
            //#name(start_download_output)
            bool start_download_output = false;

            //#port
            //#attributes(Output)
            //#name(start_buffer)
            bool start_buffer = false;

            //#port
            //#attributes(Output)
            //#name(sizeof_result_string)
            int16 sizeof_result_string = 0;

            //#port
            //#attributes(Output)
            //#name(result_string_byte)
            uint8 result_string_byte[200];

            //#port
            //#attributes(Input)
            //#name(search_var_byte)
            uint8 search_var_byte[200];
    };

    ///////////////////////////////////////////////////////////////////////////////
    // inline methods of class MyComponent
    inline MyComponent::MyComponent(IApplication& application, const String& name)
    : ComponentBase(application, ::Azure_connection_cpp::Azure_connection_cppLibrary::GetInstance(), name, ComponentCategory::Custom)
    , programProvider(*this)
    , ProgramComponentBase(::Azure_connection_cpp::Azure_connection_cppLibrary::GetInstance().GetNamespace(), programProvider)
   
    // Added: data info provider
    , dataInfoProvider(::Azure_connection_cpp::Azure_connection_cppLibrary::GetInstance().GetNamespace(), &(this->programProvider))

    // Worker Thread Example
    , workerThreadInstance(make_delegate(this, &MyComponent::workerThreadBody) , 5000, "WorkerThreadName") 
    {
    }

    #pragma region IProgramComponent implementation
    inline IProgramProvider& MyComponent::GetProgramProvider(bool /*useBackgroundDomain*/)
    {
        return this->programProvider;
    }
    #pragma endregion


    #pragma region IMetaComponent implementation
    inline IDataInfoProvider& MyComponent::GetDataInfoProvider(bool /*useBackgroundDomain*/)
    {
        return this->dataInfoProvider;
    }

    inline IDataNavigator* MyComponent::GetDataNavigator()
    {
        return nullptr;
    }
    #pragma endregion

    inline IComponent::Ptr MyComponent::Create(Arp::System::Acf::IApplication& application, const String& name)
    {
        return IComponent::Ptr(new MyComponent(application, name));
    }
} // end of namespace Azure_connection_cpp
