﻿#include "MyProgram.hpp"
#include "Arp/System/Commons/Logging.h"
#include "Arp/System/Core/ByteConverter.hpp"

namespace Azure_connection_cpp
{
	void MyProgram::Execute()
	{

	}
} // end of namespace Azure_connection_cpp
