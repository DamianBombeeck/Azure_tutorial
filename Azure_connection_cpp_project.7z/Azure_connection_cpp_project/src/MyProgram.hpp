﻿#pragma once
#include "Arp/System/Core/Arp.h"
#include "Arp/Plc/Commons/Esm/ProgramBase.hpp"
#include "Arp/System/Commons/Logging.h"
#include "MyComponent.hpp"

namespace Azure_connection_cpp
    {
    using namespace Arp;
    using namespace Arp::System::Commons::Diagnostics::Logging;
    using namespace Arp::Plc::Commons::Esm;

    //#program
    //#component(Azure_connection_cpp::MyComponent)
    class MyProgram : public ProgramBase, private Loggable<MyProgram>
    {
    public: // typedefs

    public: // construction/destruction
        MyProgram(Azure_connection_cpp::MyComponent& myComponentArg, const String& name);
        MyProgram(const MyProgram& arg) = delete;
        virtual ~MyProgram() = default;

    public: // operators
        MyProgram&  operator=(const MyProgram& arg) = delete;

    public: // properties

    public: // operations
        void    Execute() override;

    public: // Ports

    private: // fields
        Azure_connection_cpp::MyComponent& myComponent;
    };

    ///////////////////////////////////////////////////////////////////////////////
    // inline methods of class ProgramBase
    inline MyProgram::MyProgram(Azure_connection_cpp::MyComponent& myComponentArg, const String& name)
    : ProgramBase(name)
    , myComponent(myComponentArg)
    {
    }

} // end of namespace Azure_connection_cpp
